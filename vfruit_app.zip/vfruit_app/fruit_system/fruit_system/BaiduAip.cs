﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using System.IO;
using System.Web;
using System.Net;


namespace fruit_system
{
    public static class BaiduAip
    {
        private static string Api_Key = "WyWtdteYu6KODGDhxWX0Au9Y";
        private static string Secret_Key = "GFaZvyoB8zGxrGn8CqtyrtbgtbVW78kP";
        public static JObject getAccessToken()
        {
            string authHots = "https://aip.baidubce.com/oauth/2.0/token";
            HttpClient client = new HttpClient();
            List<KeyValuePair<String, String>> paraList = new List<KeyValuePair<string, string>>();
            paraList.Add(new KeyValuePair<string, string>("grant_type", "client_credentials"));
            paraList.Add(new KeyValuePair<string, string>("client_id", Api_Key));
            paraList.Add(new KeyValuePair<string, string>("client_secret", Secret_Key));
            HttpResponseMessage response = client.PostAsync(authHots, new FormUrlEncodedContent(paraList)).Result;
            String result = response.Content.ReadAsStringAsync().Result;
            JObject jObject = JObject.Parse(result);
            return jObject;
        }

        public static JObject ingredient(string access_token,string filePath)
        {
            string host = "https://aip.baidubce.com/rest/2.0/image-classify/v1/classify/ingredient?access_token=" + access_token;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(host);
            request.Method = "post";
            request.KeepAlive = true;
            // 图片的base64编码
            string base64 = getFileBase64(filePath);
            String str = "image=" + HttpUtility.UrlEncode(base64);
            byte[] buffer = Encoding.UTF8.GetBytes(str);
            request.ContentLength = buffer.Length;
            request.GetRequestStream().Write(buffer, 0, buffer.Length);
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            StreamReader reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8);
            return JObject.Parse(reader.ReadToEnd());
        }

        public static string getFileBase64(string fileName)
        {
            FileStream file = new FileStream(fileName,FileMode.Open);
            byte[] arr = new byte[file.Length];
            file.Read(arr, 0, (int)file.Length);
            string base64 = Convert.ToBase64String(arr);
            file.Close();
            return base64;
        }
    }
}
