﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using WPFMediaKit.DirectShow.Controls;
using System.ComponentModel;

namespace fruit_system
{
    /// <summary>
    /// CameraVideoInterface.xaml 的交互逻辑
    /// </summary>
    public partial class CameraVideoInterface : Window
    {
        // 根据当前电脑是否存在可用的摄像机设备
        // 向用户发起询问是否关闭程序
        public bool CloseProgram = false;
        public string[] CameraSource;
        public int CameraCount;
        public int DefaultSelectCamera = -1;
        // 照片存放路径
        private string fullPath;

        public CameraVideoInterface()
        {
            InitializeComponent();
            // 初始化摄像机相关信息
            InitCameraInfo();
        }


        // 重写当前窗口的关闭函数,令关闭按钮实现隐藏当前窗口的功能
        // 隐藏当前窗口    
        // 已测试,稳定运行,在为进行 owner 是关闭主窗口,子窗口可正常关闭
        protected override void OnClosing(CancelEventArgs e)
        {
            // 根据主窗口是否强制关闭所有窗口,来决定当前窗口是否,关闭或隐藏
            e.Cancel = !MainWindow.CloseAllSubWnd;
            this.Hide();
        }

        // 摄像头信息
        // 初始化
        private void InitCameraInfo()
        {
            // 检查当前电脑,是否存在可用摄像头,不存在则设置相关信息,并退出
            if (MultimediaUtil.VideoInputNames.Length <= 0)
            {
                CameraCount = 0;
                CameraSource = new string[] { "Null Camera" };
                IsCloseProgram();
                return;
            }
            // 获取各个可用摄像机,并更新摄像机源的数量
            CameraSource = new string[MultimediaUtil.VideoInputNames.Length + 1];
            CameraCount = MultimediaUtil.VideoInputNames.Length;
            // 获取各个可用设想的名字
            for (int i = 0; i < MultimediaUtil.VideoInputNames.Length; ++i)
                CameraSource[i] = MultimediaUtil.VideoInputNames[i];
            CameraSource[MultimediaUtil.VideoInputNames.Length] = "Off Camera";

            // 设置默认选择的摄像机索引
            DefaultSelectCamera = 0;
        }

        // 发起询问函数
        private void IsCloseProgram()
        {
            MessageBoxResult ret = MessageBox.Show("当前电脑没有可用的摄像头，是否关闭程序", "提示", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            // 如果点击 yes ,则设置程序退出
            if (ret == MessageBoxResult.Yes)
                CloseProgram = true;
        }

        // 切换摄像机
        // 检查摄像机是否正常启动,并启动或跳过
        public void ChangeCurrentUsedCamera(string CameraName)
        {
            vce.VideoCaptureSource = CameraName;
        }

        // 拍照
        public string CameraCaptureImage()
        {
            // 建立目标渲染图像器,高度为前台控件的高度,此处不能使用 .width 或 height,否则会出现错误
            // 为了避免图像出现黑边现象,需要对图像进行重新测量和缩放
            
            RenderTargetBitmap bmp = new RenderTargetBitmap((int)vce.Width, 
                (int)vce.Height, 96, 96, PixelFormats.Default);
            // videoCaptureElement 的 stretch = Fill
            vce.Measure(vce.RenderSize);
            vce.Arrange(new Rect(vce.RenderSize));
            // 指定图像渲染目标
            bmp.Render(vce);
            // 建立图像解码器,类型为 jpeg
            BitmapEncoder encoder = new JpegBitmapEncoder();
            // 将当前渲染器中的渲染位图桢加入解码器,进行解码器
            encoder.Frames.Add(BitmapFrame.Create(bmp));
            // 建立内存流 
            using (MemoryStream stream = new MemoryStream())
            {
                encoder.Save(stream);
                byte[] pics = stream.ToArray();
                string fileName = DateTime.Now.ToString("yyyMMdd-HHmmss");
                fullPath = System.IO.Path.Combine(@"C:\Users\95461\Desktop\BaiApi.Image", fileName + "_cap.jpg");
                File.WriteAllBytes(fullPath,pics);
            }
            return fullPath;
        }

        // 关闭摄像机
        public void CloseCamera()
        {
            if(vce.IsPlaying)
                vce.Stop();
        }

        // 开启设相机
        public void OpenCamera()
        {
            if (!vce.IsPlaying)
                vce.Play();
        }
    }
}
