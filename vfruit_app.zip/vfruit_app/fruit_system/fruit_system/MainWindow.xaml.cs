﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Newtonsoft.Json.Linq;
using System.Threading;

namespace fruit_system
{
    struct GoodsInfos
    {
        public string   log_id;
        public string   goods_name;
        public int   goods_count;
        public double   goods_piece;
        public double   actual_piece;
        public double   goods_discounte;
        public bool     is_fv;
    }

    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        // 默认摄像头正常颜色
        Brush CameraNormalExists = Brushes.Chocolate;
        // 默认摄像头异常颜色
        Brush CameraExceptionExists = Brushes.Red;
        // 摄像头正常工作颜色
        Brush CameraNormalWork = Brushes.Green;
        // 摄像头异常工作
        Brush CameraExceptionWork = Brushes.Red;
        // 摄像界面显示的颜色
        Brush CameraInterfaceShow = Brushes.Blue;
        // 摄像界面隐藏的颜色
        Brush CameraInterfaceHide = Brushes.Gray;
        // 确保重写了窗口关闭函数的窗口能够正确的关闭窗口
        public static bool CloseAllSubWnd = false;
        // baiduAPI 
        private string access_token;
        private JObject access_jobject;
        // 摄像头窗口对象
        CameraVideoInterface cInterface = null;
        // 随机数引擎
        Random rd = new Random();
        // 数据条数
        private int goods_count = 0;
        // 主界面的表线程
        private Thread table_thread;
        // 商品总数量
        private int goods_total_count = 0;
        // 商品总价值
        private double goods_total_piece = 0;

        public MainWindow()
        {
            InitializeComponent();
            InitCameraWnd();
            InitMainWnd();
        }

        /// <summary>
        /// Delete
        /// </summary>
        // 测试 access Token Jobject
        void testAccessToken()
        {
            FV11.Text = (string)BaiduAip.getAccessToken()["access_token"];
        }

        // 拍照上传,
        // 更新界面
        // thread 函数
        private void CaptureImageAndPostBaidu()
        {
            while(true || CloseAllSubWnd)
            {
                // 拍照并保存照片路径
                string path = cInterface.CameraCaptureImage();
                // 上传照片到百度,并获取返回值
                JObject jObject = BaiduAip.ingredient(access_token, path);
                // 解析数据并更新UI
                GoodsInfos gd = AnalysisJsData(jObject);
                // 如果当前商品是果蔬累,更新界面
                if(gd.is_fv)
                    UpdateForUI(gd, (goods_count + 1).ToString());

                //((TextBox)this.FindName("FV11")).Text;
                UpdateForUI(gd, (goods_count + 1).ToString());
                // 每 1.5s 进行一次拍照抓取
                Thread.Sleep(1500);
            }
        }

        

        // 显示果蔬商品信息到UI 界面
        private void UpdateForUI(GoodsInfos gd,string line)
        {
            _UpdateForUI(gd.log_id, "FV" + line + "1");
            _UpdateForUI(gd.goods_name, "FV" + line + "2");
            _UpdateForUI(gd.goods_count, "FV" + line + "3");
            _UpdateForUI(gd.goods_piece, "FV" + line + "4");
            _UpdateForUI(gd.goods_discounte, "FV" + line + "5");
            _UpdateForUI(gd.actual_piece, "FV" + line + "6");
            // 更新收银界面
            _UpdateTotalGoodsCount(gd.goods_count);
            _UpdateTotalGoodsPiece(gd.goods_piece);
            // 增加计数,已有商品数量
            goods_count++;
        }

        // 更新上一单的信息
        private void _UpdateLastPayInfo()
        {   // 更新上一单的金额
            LastValueContent.Text = goods_total_piece.ToString();
            // 更新上一单的找零
            LastReturnContent.Text = (rd.Next(0, (int)goods_total_piece % 100).ToString());
        }

        // 更新收银表格, 商品总数量
        private void _UpdateTotalGoodsCount(int fruit_count)
        {
            goods_total_count += fruit_count;
            TotalCountValue.Text = goods_total_count.ToString();
        }
        // 更新收银表格 , 商品总价值
        private void _UpdateTotalGoodsPiece(double fruit_actual_piece)
        {
            goods_total_piece += fruit_actual_piece;
            TotalMoneyValue.Text = goods_total_piece.ToString();
        }
        // 更新收银表格为空
        private void _UpdateMoneyBoxAsNull()
        {
            TotalCountValue.Text = null;
            TotalMoneyValue.Text = null;
        }
        // 更新商品表格为空
        private void _UpdateForUI(string objName)
        {
            TextBox tb = this.FindName(objName) as TextBox;
            tb.Text = "";
        }

        // 更新商品表格
        private void _UpdateForUI(string gf,string objName)
        {
            TextBox tb = this.FindName(objName) as TextBox;
            tb.Text = gf;
        }
        // 更新商品表格
        private void _UpdateForUI(double gf,string objName)
        {
            TextBox tb = this.FindName(objName) as TextBox;
            tb.Text = gf.ToString();
        }


        // 解析 baidu 数据 
        private GoodsInfos AnalysisJsData(JObject jObject)
        {
            GoodsInfos gd = new GoodsInfos();
            string goods_name = (string)jObject["result"][0]["name"];
            // 如果当前照片不是果蔬是才,直接返回
            if (goods_name.CompareTo("非果蔬食材") == 0)
            {
                gd.is_fv = false;
                return gd;
            }
            gd.is_fv = true;
            gd.goods_name = goods_name;
            gd.log_id = (string)jObject["log_id"];
            gd.goods_piece = (rd.Next(3,15));   //  3-15 元
            gd.goods_count = (rd.Next(1,4));    //  1 - 4 个
            gd.goods_discounte = (rd.Next(7, 10)) / 10.0f; // 0 - 1.0f;
            gd.actual_piece = gd.goods_count * gd.goods_piece * gd.goods_discounte;
            return gd;
        }



        // 初始化摄像头窗体，并进行必要检测
        // 如果当前PC没有可用的摄像则，退出程序运行
        private void InitCameraWnd()
        {
            cInterface = new CameraVideoInterface();
            if (cInterface.CloseProgram == true)
            {
                Application.Current.Shutdown();
            }
        }
        // 确保子窗口一定被关闭,程序正常退出
        protected override void OnClosing(CancelEventArgs e)
        {
            base.OnClosing(e);
            // 关闭子窗口
            CloseAllSubWnd = true;
            cInterface.Close();
            // 退出线程
            table_thread.Abort();
        }

        // 初始化当前窗口的部分数据
        private void InitMainWnd()
        {
            CameraList.ItemsSource = cInterface.CameraSource;
            CameraList.SelectedIndex = cInterface.DefaultSelectCamera;
            // 如果可用摄像头数量为0，退出
            if (cInterface.CameraCount == 0)
            {
                InitCameraStatusUi(false, false, false);
                return;
            }
            InitCameraStatusUi(true, true, false);

            // 获取百度 access Jobject
            access_jobject = BaiduAip.getAccessToken();
            // 获取百度的 access_token
            access_token = (string)access_jobject["access_token"];

            // 初始化 表格线程
            table_thread = new Thread(CaptureImageAndPostBaidu);

            this.Loaded += HintCameraWndAndSTableThread;

        }
        // 初始化摄像机窗口
        // 最后开始 启动表格线程
        private void HintCameraWndAndSTableThread(object sender, RoutedEventArgs e)
        {
            cInterface.ShowInTaskbar = true;
            cInterface.WindowState = WindowState.Minimized;
            cInterface.Show();
            cInterface.Owner = this;
            cInterface.Hide();

            // 最后启动 表格线程
            //table_thread.Start();
        }

        // 更新摄像头的状态 UI 显示
        private void InitCameraStatusUi(bool exists,bool work,bool openUI)
        {
            CameraExists(exists);
            CameraWork(work);
            CameraUI(openUI);
        }
        // 更新摄像头存在与否状态 UI
        private void CameraExists(bool stat)
        {
            if (stat)
            {
                CameraExceptStatus.Fill = CameraNormalExists;
                return;
            }
            CameraExceptStatus.Fill = CameraExceptionExists;
        }

        // 更新摄像头正常工作的颜色
        private void CameraWork(bool stat)
        {
            if (stat)
            {
                CameraNormalStatus.Fill = CameraNormalWork;
                return;
            }
            CameraExceptStatus.Fill = CameraExceptionWork;
        }

        // 摄像头界面显示 
        private void CameraUI(bool stat)
        {
            if (stat)
            {
                CameraInterfaceSOrN.Fill = CameraInterfaceShow;
                return;
            }
            CameraInterfaceSOrN.Fill = CameraInterfaceHide;
        }

        /// <summary>
        /// 测试对返回信息的 uri 显示的点击访问
        /// </summary>
        void TestUri()
        {
            bai_ke.NavigateUri = new System.Uri("https://www.baidu.com/");
            UriInterFace.Text = "https://www.baidu.com/";
        }


        // 根据列表切换当前使用的摄像机
        private void CameraList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if ((string)CameraList.SelectedItem != "Off Camera")
            {
                cInterface.ChangeCurrentUsedCamera((string)CameraList.SelectedItem);
                return;
            }
            ToCloseCameraInterfaceWnd();
        }
        // 再次开启 CameraInterface
        private void ReopenCameraInterfaceWnd()
        {
            if (cInterface == null)
                cInterface = new CameraVideoInterface();
        }

        // 主动关闭 CameraInterface 界面
        private void ToCloseCameraInterfaceWnd()
        {
            cInterface.Close();
        }

        private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
        {
            System.Diagnostics.Process.Start(e.Uri.AbsoluteUri);
        }

        private void CameraBtn_Click(object sender, RoutedEventArgs e)
        {
            cInterface.Show();
            cInterface.WindowState = WindowState.Normal;
        }

        // 通过按键 W 调取函数 test
        /// <summary>
        /// Delete
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Test_CameraToBaiduAip(object sender, KeyEventArgs e)
        {
            switch (e.Key)
            {
                case Key.F1:
                    F1Help();
                    break;
                case Key.F2:
                    F2About();
                    break;
                case Key.F3:
                    F3Pay();
                    break;
                case Key.F4:
                    F4Cancel();
                    break;
                case Key.F5:
                    F5TestSoft();
                    break;
                case Key.F6:
                    F6CallBaidu();
                    break;
                case Key.F9:
                    F9TestCaptureCamera();
                    break;
                default:

                    break;
            }
        }



        // 清空表格
        private void _ClearTableData()
        {
            // 清0数据
            goods_count = 0;
            goods_total_count = 0;
            goods_total_piece = 0;

            for (int i = 1; i <= 10;++i)
            {
                for(int j = 1; j <= 6;j++)
                {
                    _UpdateForUI("FV" + i.ToString() + j.ToString());
                }
            }
            _UpdateMoneyBoxAsNull();
        }

        /// <summary>
        /// F1 按键响应消息
        /// </summary>
        private void F1Help()
        {
            MessageBox.Show("帮助消息,当前软件没有帮助", "帮助", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        /// <summary>
        /// f2 按键响应消息
        /// </summary>
        private void F2About()
        {
            MessageBox.Show("关于消息,当前软件没有关于", "关于", MessageBoxButton.OK, MessageBoxImage.Information);
        }


        private void F3Pay()
        {
            var ret = MessageBox.Show("开始结算", "结算支付", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (ret != MessageBoxResult.Yes)
                return;
            // 更新本次付款信息,到最新付款信息栏
            _UpdateLastPayInfo();
            // 清空表格
            _ClearTableData();
        }

        /// <summary>
        /// F4 按键响应消息
        /// </summary>
        private void F4Cancel()
        {
            _ClearTableData();
        }
        /// <summary>
        /// F5 按键响应消息
        /// </summary>
        private void F5TestSoft()
        {
            if (goods_count == 10)
                return;
            GoodsInfos gd;
            for (int i = 0; i < 10; ++i)
            {
                gd = test_gd();
                UpdateForUI(gd, (goods_count + 1).ToString());
            }
        }
        /// <summary>
        /// TEST  Delete
        /// </summary>
        /// <returns></returns>
        private GoodsInfos test_gd()
        {
            GoodsInfos gd = new GoodsInfos();
            gd.goods_count = rd.Next(15, 20);
            gd.goods_discounte = rd.Next(0, 10) / 10.0f;
            gd.goods_name = "goods_name";
            gd.goods_piece = rd.Next(1, 15);
            gd.is_fv = true;
            gd.actual_piece = gd.goods_count * gd.goods_piece * gd.goods_discounte;
            gd.log_id = "qwwq8eqwe7qw8e7qw8e712541";
            return gd;
        }

        /// <summary>
        /// F6 按键响应消息
        /// </summary>
        private void F6CallBaidu()
        {
            System.Diagnostics.Process.Start("https://www.baidu.com/");
        }

        

        private void F9TestCaptureCamera()
        {
            // 拍照并保存照片路径
            string path = cInterface.CameraCaptureImage();
            // 上传照片到百度,并获取返回值
            JObject jObject = BaiduAip.ingredient(access_token, path);
            // 解析数据并更新UI
            GoodsInfos gd = AnalysisJsData(jObject);
            // 如果当前商品是果蔬累,更新界面
            if (gd.is_fv)
                UpdateForUI(gd, (goods_count + 1).ToString());

        }
    }
}
